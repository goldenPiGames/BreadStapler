function BGFlying() {
	
}
BGFlying.prototype.draw = function() {
	ctx.fillStyle = "#55AAEE";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
}