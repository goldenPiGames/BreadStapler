function BGSync() {
	
}