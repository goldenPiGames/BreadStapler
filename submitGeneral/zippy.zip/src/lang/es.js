LANG.es = {
	"lang-name" : "Español",
	"lang-credits" : ["Ayúdame"],
	
	"title" : "GRAPADORA de PAN",
	"mainmenu-subtitle" : "Necesito traducción",
	
}